export class Story {
  constructor(
    public id: number,
    public name_user: string,
    public name: string,
    public description: string,
    public imageUrl: string
  ) {

  }
}
