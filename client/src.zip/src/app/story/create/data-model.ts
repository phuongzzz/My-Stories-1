export class Step {
  name = '';
  content = '';
}
